import win32gui
import win32con
import re

def cerrar_pestañas():
    """
    Cierra pestañas del Explorador de archivos si hay al menos una abierta.

    Args:
        Ninguno.

    Returns:
        Ninguno.
    """

    def callback(hwnd, extra):
        nonlocal count
        try:
            # Listar posibles clases de ventana del Explorador
            explorer_classes = ["Explorer", "CabinetWClass", "WorkerW"]
            if win32gui.GetClassName(hwnd) in explorer_classes:
                title = win32gui.GetWindowText(hwnd).lower()
                if re.search(r"explorador|descargas|documentos|música|C:|archivos|inicio|drive|G:|unimeq|2024|informes|escritorio|equipo|ing|reportes|causas|factura|facturacion|clientes|junio|pix", title, re.IGNORECASE):
                    if win32gui.IsWindowVisible(hwnd) and win32gui.IsWindowEnabled(hwnd) and not win32gui.GetParent(hwnd):
                        count += 1
                        win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
                        print(f"Cerrando pestaña: {title}")
        except Exception as e:
            print(f"Error al procesar la ventana: {e}")

    count = 0
    win32gui.EnumWindows(callback, None)

    # Verificar si se encontraron pestañas abiertas
    if count > 0:
        print(f"Se cerraron {count} pestañas del Explorador de archivos.")
    else:
        print("No se encontraron pestañas del Explorador de archivos abiertas.")

# Ejecutar la función
cerrar_pestañas()
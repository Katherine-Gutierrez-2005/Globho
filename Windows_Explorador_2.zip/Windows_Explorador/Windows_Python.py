# -*- coding: utf-8 -*-

import os

def buscar_carpeta(nombre_carpeta, ruta_inicial="C:\\"):
    """Busca una carpeta de forma recursiva a partir de un directorio inicial.

    Definición:
        nombre_carpeta (str): Nombre de la carpeta a buscar.
        ruta_inicial (str, optional): Directorio inicial de la búsqueda. Por defecto es: "C:\\".

    Retorno:    
        str: Ruta completa de la carpeta si se encuentra, o None si no se encuentra.
    """

    for root, dirs, files in os.walk(ruta_inicial):
        if nombre_carpeta in dirs:
            return os.path.join(root, nombre_carpeta)

    return None

if __name__ == "__main__":
    carpeta_buscada = "Windows_Explorador"
    ruta_completa = buscar_carpeta(carpeta_buscada)

    if ruta_completa:
        print(f"La carpeta se encontró en: {ruta_completa}")
        os.startfile(ruta_completa)
    else:
        print(f"No se encontró la carpeta '{carpeta_buscada}'.")
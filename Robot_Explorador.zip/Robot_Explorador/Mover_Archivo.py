import os
import shutil
import datetime
import subprocess
import time
import pyautogui
import tkinter as tk

def organizar_archivos_por_mes(origen, destino):
    ventana_error = None
    ocurre_un_error = False
    # Se verifica si las rutas existen
    if not os.path.exists(origen):
        print(f"La ruta de origen '{origen}' no existe.")
        return
    if not os.path.exists(destino):
        os.makedirs(destino)
    else:
        if not os.access(destino, os.W_OK):
            print(f"No tienes permisos de escritura en '{destino}'.")
            return

    año_actual = datetime.datetime.now().year

    for archivo in os.listdir(origen):
        if archivo.endswith(".xlsx"):
            try:
                # Se extrae el mes del nombre del archivo (Formato AAAA-MM-DD)
                mes = archivo.split("-")[1]

                # Crea la ruta de la carpeta de destino
                carpeta_año = os.path.join(destino, str(año_actual))
                os.makedirs(carpeta_año, exist_ok=True)
                carpeta_destino = os.path.join(carpeta_año, f"Carpeta Informes {mes} {año_actual}")
                os.makedirs(carpeta_destino, exist_ok=True)

                # Ruta completa del archivo de origen y destino
                origen_completo = os.path.join(origen, archivo)
                destino_completo = os.path.join(carpeta_destino, archivo)

                # Mueve el archivo y abre la carpeta de destino
                shutil.move(origen_completo, destino_completo)
                print(f"Archivo {archivo} movido a {carpeta_destino}")

                if os.name == 'nt':
                    os.startfile(carpeta_destino)
                    
                elif os.name == 'posix':
                    subprocess.call(["open", carpeta_destino])
                
                if ocurre_un_error:
                    ventana_error = tk.Tk()
            except Exception as e:
                ventana_error = tk.Tk()
                print(f"Error al mover el archivo {archivo}: {e}")
                # Crear un label para mostrar el mensaje de error
                mensaje_error = tk.Label(ventana_error, text=f"Error al mover el archivo {archivo}: {e}")
                mensaje_error.pack(pady=20)
            else:
                # Si no hay error, puedes mostrar un mensaje de éxito o realizar otra acción
                print(f"Archivo {archivo} movido correctamente")

                # Crear el botón y el bucle principal siempre que ventana_error exista
                if ventana_error:
                    boton_cerrar = tk.Button(ventana_error, text="Cerrar", command=ventana_error.destroy)
                    boton_cerrar.pack()
                    ventana_error.mainloop()
                
# Ruta de Inicio (donde está el archivo modificado) y la ruta donde se va a guardar acorde al nombre
origen = r"C:\Robot_Explorador"
destino = r"C:\Robot_Explorador\Reportes"
organizar_archivos_por_mes(origen, destino)
import os
from pathlib import Path

def eliminar_archivos_infhistoriaplano():
    """Elimina todos los archivos que contengan 'InfHistoriaPlano' en el directorio de descargas.
    """

    # Obtener la ruta al directorio de descargas del usuario actual
    directorio_descargas = str(Path.home() / "Descargas")

    archivos_eliminados = 0
    for root, dirs, files in os.walk(directorio_descargas):
        for file in files:
            if "InfHistoriaPlano" in file:
                ruta_completa = os.path.join(root, file)
                print(f"Eliminando archivo: {ruta_completa}")
                os.remove(ruta_completa)
                archivos_eliminados += 1

    if archivos_eliminados == 0:
        print("No se encontraron archivos para eliminar.")
    else:
        print(f"Se eliminaron {archivos_eliminados} archivos.")

# Llamar a la función
eliminar_archivos_infhistoriaplano()
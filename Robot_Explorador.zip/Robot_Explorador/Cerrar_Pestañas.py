import win32gui
import win32con

def cerrar_todas_pestañas_explorador():
    """
    Cierra todas las ventanas del Explorador de archivos y muestra un informe detallado.

    Args:
        Ninguno.

    Returns:
        list: Lista de títulos de las ventanas cerradas.
    """

    ventanas_cerradas = []

    def callback(hwnd, extra):
        nonlocal ventanas_cerradas
        try:
            # Comprueba si la ventana es del Explorador
            if win32gui.GetClassName(hwnd) in ["Explorer", "CabinetWClass", "WorkerW", "ExploreW"]:
                titulo = win32gui.GetWindowText(hwnd)
                if titulo:
                    ventanas_cerradas.append(titulo)
                    win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
                    print(f"Cerrando ventana: {titulo}")
        except Exception as e:
            print(f"Error al procesar la ventana: {e}")

    win32gui.EnumWindows(callback, None)
    return ventanas_cerradas

# Ejecutar la función
ventanas_cerradas = cerrar_todas_pestañas_explorador()
print(f"Se cerraron {len(ventanas_cerradas)} pestañas del Explorador de archivos:")
for ventana in ventanas_cerradas:
    print(f"- {ventana}")
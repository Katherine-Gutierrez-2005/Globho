import os
import shutil
import datetime

def organizar_archivos_por_mes(origen, destino):
    """Se organiza archivos .xlsx por mes en una estructura de carpetas.

    Args:
        origen (str): Ruta de la carpeta de origen la que en este caso es Windows_Explorador que está en el Disco Local C: del equipo.
        destino (str): Ruta de la carpeta de destino, la cual es reportes,
        si la carpeta del presente mes no está automáticamente la crea y mueve el archivo correspondiente, y si está, solo mueve el archivo.
    """

    # Se verifica si las rutas existen
    if not os.path.exists(origen):
        print(f"La ruta de origen '{origen}' no existe.")
        return
    if not os.path.exists(destino):
        os.makedirs(destino)
    else:
        if not os.access(destino, os.W_OK):
            print(f"No tienes permisos de escritura en '{destino}'.")
            return

    año_actual = datetime.datetime.now().year

    for archivo in os.listdir(origen):
        if archivo.endswith(".xlsx"):
            try:
                # Se extrae el mes del nombre del archivo (Formato AAAA-MM-DD)
                mes = archivo.split("-")[1]

                # Crea la ruta de la carpeta de destino, en el caso que no esté,si está, pasa a la línea 36, donde verifica si la carpeta del presente mes se encuentra
                carpeta_año = os.path.join(destino, str(año_actual))
                os.makedirs(carpeta_año, exist_ok=True)
                carpeta_destino = os.path.join(carpeta_año, f"Carpeta Informes {mes} {año_actual}")
                os.makedirs(carpeta_destino, exist_ok=True)

                # Ruta completa del archivo de origen y destino
                origen_completo = os.path.join(origen, archivo)
                destino_completo = os.path.join(carpeta_destino, archivo)

                # Mueve el archivo y muestra un mensaje de confirmación
                shutil.move(origen_completo, destino_completo)
                print(f"Archivo {archivo} movido a {carpeta_destino}")

            except Exception as e:
                print(f"Error al mover el archivo {archivo}: {e}")

# Ruta de Inicio (donde está el archivo modificado) y la ruta donde se va a guardar acorde al nombre
origen = r"C:\Windows_Explorador"
destino = r"C:\Windows_Explorador\Reportes"
organizar_archivos_por_mes(origen, destino)
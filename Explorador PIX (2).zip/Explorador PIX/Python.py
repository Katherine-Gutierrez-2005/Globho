import os
import shutil
import datetime

def organizar_archivos_por_mes(origen, destino):

    año_actual = datetime.datetime.now().year  # Obtener el año actual

    carpeta_año = os.path.join(destino, str(año_actual))  # Crear la ruta de la carpeta del año

    os.makedirs(carpeta_año, exist_ok=True)  # Crear la carpeta del año si no existe

    for archivo in os.listdir(origen):
        if archivo.endswith(".xlsx"):
            # Extraer el mes (asumiendo formato AAAA-MM-DD)
            mes = archivo.split("-")[1]

            # Crear la carpeta de destino
            carpeta_destino = os.path.join(carpeta_año, f"Carpeta Informes {mes} {año_actual}")
            os.makedirs(carpeta_destino, exist_ok=True)

            # Mover el archivo a esa carpeta de destino
                
            print(f"Archivo {archivo} movido a {carpeta_destino}")

#Ruta de Inicio (donde está el archivo modificado) y la ruta donde se va a guardar acorde al nombre
origen = "C:\Explorador PIX"
destino = "C:\Explorador PIX\Reportes"
organizar_archivos_por_mes(origen, destino)
